//task 1
// alert("Yura");

//task 2
// console.log("Yanchynskyi");

//task 3
// let variable1, variable2;
// variable1 = "variable 1";
// variable2 = "variable 2";
// console.log(variable1, variable2);
// variable2 = variable1;
// console.log(variable1, variable2);

//task 4
// const person = {
//   name: "John",
//   age: "21",
//   employed: true,
//   relatives,
//   data: null,
//   };

//task 5
// let isAdult = confirm("Are you adult?");
// console.log(isAdult);

// //task 6
// const name = "Yura";
// const lastname = "Yanchynskyi";
// const group = 21;
// const birthYear = 2003;
// const married = false;
// console.log(
//   group,
//   typeof group,
//   birthYear,
//   typeof birthYear,
//   married,
//   typeof married,
//   name,
//   typeof name,
//   lastname,
//   typeof lastname
// );
// let variable1 = null;
// let variable2;
// console.log(typeof variable1, typeof variable2);

//task 7
// let name = prompt("What's your name?");
// let email = prompt("What's your email");
// let password = prompt("What's your password");
// alert(
//   "Dear " + name + ", your email is " + email + ", your password is " + password
// );

// //task 8
// let secondsInHour = 60 * 60;
// let secondsIn24Hours = 60 * 60 * 24;
// let secondsInMonth = 60 * 60 * 24 * 30;
// alert("Seconds in hour: " + secondsInHour);
// alert("Seconds in 24hours: " + secondsIn24Hours);
// alert("Seconds in month: " + secondsInMonth);
